package com.imcys.bilibilias.common.data.repository

import com.imcys.bilibilias.common.data.dao.RoamDao

class RoamRepository(private val dao: RoamDao)  {



}