package com.imcys.bilibilias.tool_roam.model

import com.imcys.bilibilias.common.data.entity.RoamInfo

data class RoamItemBean(
    val tag :Int,
    val roamInfo: RoamInfo?
)
