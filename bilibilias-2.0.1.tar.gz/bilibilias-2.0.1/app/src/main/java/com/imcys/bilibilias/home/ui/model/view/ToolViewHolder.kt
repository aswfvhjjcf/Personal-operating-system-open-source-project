package com.imcys.bilibilias.home.ui.model.view

import android.content.Context
import android.content.Intent
import com.imcys.bilibilias.databinding.FragmentToolBinding
import com.imcys.bilibilias.home.ui.activity.AsVideoActivity

class ToolViewHolder(
    val context: Context,
    private val binding: FragmentToolBinding,
) {

}