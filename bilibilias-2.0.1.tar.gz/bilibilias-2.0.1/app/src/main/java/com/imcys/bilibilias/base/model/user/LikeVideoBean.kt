package com.imcys.bilibilias.base.model.user

data class LikeVideoBean(
    val code: Int,
    val message: String,
    val ttl: Int
)