package com.imcys.bilibilias.tool_livestream

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class LiveStreamActivity :AppCompatActivity(){

}